package com.rarchives.ripme.tst.ripper.rippers;

import java.io.IOException;
import java.net.URL;

import com.rarchives.ripme.ripper.rippers.PhotobucketRipper;

public class PhotobucketRipperTest extends RippersTest {
    /*
    // https://github.com/RipMeApp/ripme/issues/229 : Disabled test (temporary) : BasicRippersTest#testPhotobucketRip (timing out)
    public void testPhotobucketRip() throws IOException {
        PhotobucketRipper ripper = new PhotobucketRipper(new URL("http://s844.photobucket.com/user/SpazzySpizzy/library/Album%20Covers?sort=3&page=1"));
        testRipper(ripper);
        deleteSubdirs(ripper.getWorkingDir());
        deleteDir(ripper.getWorkingDir());
    }
    */
}




//package com.rarchives.ripme.tst.ripper.rippers;
//
//import java.io.IOException;
//import java.net.URL;
//
//import com.rarchives.ripme.ripper.rippers.FivehundredpxRipper;
//
//public class FivehundredpxRipperTest extends RippersTest {
//    public void test500pxAlbum() throws IOException {
//        FivehundredpxRipper ripper = new FivehundredpxRipper(new URL("https://marketplace.500px.com/alexander_hurman"));
//        testRipper(ripper);
//    }
//}

// Ripper is broken. See https://github.com/RipMeApp/ripme/issues/438
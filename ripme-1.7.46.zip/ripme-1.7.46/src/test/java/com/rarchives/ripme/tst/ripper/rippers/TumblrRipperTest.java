
package com.rarchives.ripme.tst.ripper.rippers;

import java.io.IOException;
import java.net.URL;

import com.rarchives.ripme.ripper.rippers.TumblrRipper;

public class TumblrRipperTest extends RippersTest {
    // https://github.com/RipMeApp/ripme/issues/250
    /*
    public void testTumblrFullRip() throws IOException {
        TumblrRipper ripper = new TumblrRipper(new URL("http://wrouinr.tumblr.com/archive"));
        testRipper(ripper);
    }
    public void testTumblrTagRip() throws IOException {
        TumblrRipper ripper = new TumblrRipper(new URL("http://topinstagirls.tumblr.com/tagged/berlinskaya"));
        testRipper(ripper);
    }
    public void testTumblrPostRip() throws IOException {
        TumblrRipper ripper = new TumblrRipper(new URL("http://sadbaffoon.tumblr.com/post/132045920789/what-a-hoe"));
        testRipper(ripper);
    }
    */
}

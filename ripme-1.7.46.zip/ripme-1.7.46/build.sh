#!/usr/bin/env bash
mvn clean compile assembly:single
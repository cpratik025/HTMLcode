* Ripme version:
* Java version: <!-- (output of `java -version`) -->
* Operating system: <!-- (if Windows, output of `ver` or `winver`) -->
* Exact URL you were trying to rip when the problem occurred:
* Please include any additional information about how to reproduce the problem:

## Expected Behavior

Detail the expected behavior here.

## Actual Behavior

Detail the actual (incorrect) behavior here. You can post log snippets or attach log files to your issue report.

# Restaurant-Management-System
This is a restaurant management software which I developed for one of the assignment in Programming one course.
